# Shattered Riffs - Rock the Night

## Brief Description
Shattered Riffs is a high-energy web platform designed for a rock band and music festival. The project features a dynamic landing page that integrates upcoming tour dates, band information, and a dedicated "Food Zone" section to showcase the festival's gastronomic experience. It is built with a focus on bold aesthetics, responsive design, and clear calls to action for fans and attendees.

## Technologies Used
*   **HTML5:** Semantic markup for structure and accessibility.
*   **CSS3:** Custom styling including Flexbox, Grid layouts, and responsive media queries.
*   **Google Fonts:** "Montserrat" for modern typography.
*   **Font Awesome:** For professional iconography throughout the site.

## Project Structure
The project is organized as follows:
```bash
├── assets/          # Contains images (hero, gallery photos, and icons)
├── css/             
│   └── style.css    # All layout and design styles
├── scrip.js         # JavaScript for navigation and interactivity
└── index.html       # Main HTML document and entry point
```

## How to run or view the project locally
1.  **Clone or Download:** Download the project files as a ZIP or clone the repository to your computer.
2.  **Locate the Folder:** Open the main project folder.
3.  **Launch the Site:** 
    *   Simply double-click the `index.html` file to open it in your default web browser.
    *   Alternatively, if you are using **VS Code**, you can right-click `index.html` and select **"Open with Live Server"** for an optimal development experience.

---
**Note:** Ensure the `assets/`, `css/`, and `scrip.js` paths remain unchanged for the styles and images to load correctly.

